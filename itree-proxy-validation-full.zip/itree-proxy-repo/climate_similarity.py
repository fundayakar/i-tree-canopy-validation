"""
climate_similarity.py
=====================

Quantitative proxy-region selection framework for i-Tree Canopy applications
in data-scarce regions.

Computes a multivariate climate similarity score between Ankara (target) and
candidate proxy cities drawn from i-Tree's available regional datasets
(USA, UK, Ukraine, Sweden, New Zealand, South Korea), plus additional U.S.
cities to test within-country sensitivity.

Method
------
1. Five bioclimatic indicators are computed from monthly normals (1991-2020):
     MAT   - Mean Annual Temperature (degC)
     MAP   - Mean Annual Precipitation (mm)
     TSEAS - Temperature seasonality (warmest minus coldest monthly mean, degC)
     PSEAS - Precipitation seasonality (CV of monthly precipitation, %)
     AI    - De Martonne aridity index, MAP / (MAT + 10)
2. Indicators are z-score standardized across all candidate cities.
3. Euclidean distance from Ankara is computed in the 5-D standardized space.
4. Cosine similarity is reported as a complementary directional metric.

Data sources
------------
Monthly climate normals (1991-2020) compiled from WorldClim v2.1 and
national meteorological services (TSMS for Ankara, NOAA for U.S. cities,
UK Met Office, UKHMI for Kyiv, SMHI for Stockholm, NIWA for Auckland,
KMA for Seoul). Values are publicly available climatological normals.

Outputs
-------
bioclim_raw.csv         Raw bioclimatic indicators per city
bioclim_zscore.csv      Standardized indicators
similarity_ranking.csv  Ranked Euclidean distance and cosine similarity vs Ankara

Author: Funda Yakar (fundayakar@gmail.com)
ORCID:  0000-0002-7082-3956
"""

import numpy as np
import pandas as pd
from pathlib import Path

OUTPUT_DIR = Path(__file__).parent / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

# -----------------------------------------------------------------------------
# Climate normals (1991-2020). Monthly means: temperature in degC, precipitation
# in mm. Order: Jan, Feb, Mar, ..., Dec.
# -----------------------------------------------------------------------------

cities = {
    "Ankara": {
        "country": "Turkiye",
        "T_monthly":  [0.3, 1.7, 5.8, 11.2, 16.0, 20.1, 23.6, 23.5, 18.9, 13.0, 6.8, 2.3],
        "P_monthly":  [42, 35, 39, 42, 51, 35, 14, 12, 18, 28, 32, 47],
    },
    "Denver_USA": {
        "country": "USA",
        "T_monthly":  [-0.6, 0.7, 4.7, 9.3, 14.6, 20.4, 23.8, 22.6, 17.6, 10.6, 3.9, -0.6],
        "P_monthly":  [12, 14, 33, 44, 58, 50, 47, 42, 31, 25, 19, 14],
    },
    "Salt_Lake_City_USA": {
        "country": "USA",
        "T_monthly":  [-0.6, 1.7, 6.8, 11.0, 16.2, 22.2, 26.9, 25.7, 20.2, 12.6, 5.2, 0.0],
        "P_monthly":  [33, 35, 47, 52, 49, 22, 14, 19, 28, 39, 36, 33],
    },
    "Phoenix_USA": {
        "country": "USA",
        "T_monthly":  [13.0, 14.8, 18.2, 22.3, 27.4, 32.7, 35.0, 34.0, 30.7, 24.1, 17.0, 12.6],
        "P_monthly":  [22, 24, 27, 6, 4, 1, 24, 25, 19, 16, 17, 26],
    },
    "Boston_USA": {
        "country": "USA",
        "T_monthly":  [-1.5, -0.5, 3.6, 9.4, 15.2, 20.4, 23.6, 22.7, 18.8, 12.7, 7.0, 1.5],
        "P_monthly":  [88, 82, 105, 96, 89, 83, 79, 84, 87, 99, 97, 102],
    },
    "London_UK": {
        "country": "United_Kingdom",
        "T_monthly":  [5.2, 5.3, 7.6, 9.9, 13.3, 16.5, 18.7, 18.5, 15.7, 12.0, 8.0, 5.5],
        "P_monthly":  [55, 41, 42, 44, 49, 45, 45, 50, 49, 69, 59, 55],
    },
    "Kyiv_Ukraine": {
        "country": "Ukraine",
        "T_monthly":  [-3.5, -2.4, 2.4, 9.6, 15.5, 18.5, 20.5, 19.7, 14.3, 8.4, 2.4, -1.7],
        "P_monthly":  [48, 46, 39, 49, 53, 73, 88, 69, 47, 35, 51, 52],
    },
    "Stockholm_Sweden": {
        "country": "Sweden",
        "T_monthly":  [-1.6, -1.7, 1.0, 5.6, 11.4, 15.7, 18.2, 17.3, 12.8, 7.7, 3.4, 0.0],
        "P_monthly":  [39, 27, 26, 30, 30, 45, 72, 66, 55, 50, 53, 46],
    },
    "Auckland_NZ": {
        "country": "New_Zealand",
        "T_monthly":  [19.7, 20.0, 18.7, 16.3, 13.7, 11.5, 10.5, 11.1, 12.6, 14.2, 15.9, 18.1],
        "P_monthly":  [73, 66, 87, 99, 112, 126, 145, 118, 105, 100, 86, 92],
    },
    "Seoul_South_Korea": {
        "country": "South_Korea",
        "T_monthly":  [-1.9, 0.7, 6.1, 12.6, 17.8, 22.1, 25.0, 25.7, 21.2, 14.8, 7.2, 0.4],
        "P_monthly":  [21, 24, 46, 77, 102, 133, 395, 364, 169, 52, 53, 25],
    },
}


def compute_bioclim(T_monthly, P_monthly):
    """Compute the five bioclimatic indicators from monthly normals."""
    T = np.array(T_monthly)
    P = np.array(P_monthly)
    MAT = T.mean()
    MAP = P.sum()
    TSEAS = T.max() - T.min()
    PSEAS = (P.std(ddof=0) / P.mean()) * 100  # CV in percent
    AI = MAP / (MAT + 10)                     # De Martonne index
    return MAT, MAP, TSEAS, PSEAS, AI


def cosine_similarity(a, b):
    """Cosine similarity between two vectors."""
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))


def main():
    # 1. Compute raw indicators
    records = []
    for name, data in cities.items():
        MAT, MAP, TSEAS, PSEAS, AI = compute_bioclim(data["T_monthly"], data["P_monthly"])
        records.append({
            "City": name,
            "Country": data["country"],
            "MAT": MAT, "MAP": MAP, "TSEAS": TSEAS, "PSEAS": PSEAS, "AI": AI,
        })
    df = pd.DataFrame(records).set_index("City")

    print("=" * 75)
    print("RAW BIOCLIMATIC INDICATORS")
    print("=" * 75)
    print(df.drop(columns=["Country"]).round(2).to_string())
    print()

    # 2. Z-score standardization
    numeric = df.drop(columns=["Country"])
    df_z = (numeric - numeric.mean()) / numeric.std(ddof=0)

    print("=" * 75)
    print("STANDARDIZED (z-score) BIOCLIMATIC INDICATORS")
    print("=" * 75)
    print(df_z.round(3).to_string())
    print()

    # 3. Euclidean distance and cosine similarity vs Ankara
    ankara_z = df_z.loc["Ankara"].values
    distances, cosines = {}, {}
    for city in df_z.index:
        if city == "Ankara":
            continue
        v = df_z.loc[city].values
        distances[city] = float(np.sqrt(np.sum((v - ankara_z) ** 2)))
        cosines[city] = float(cosine_similarity(ankara_z, v))

    ranking = pd.DataFrame({
        "Euclidean_distance": pd.Series(distances),
        "Cosine_similarity": pd.Series(cosines),
    }).sort_values("Euclidean_distance")

    print("=" * 75)
    print("CLIMATE SIMILARITY RANKING vs ANKARA")
    print("=" * 75)
    print("(lower Euclidean = more similar; cosine closer to 1 = more similar shape)")
    print()
    print(ranking.round(3).to_string())
    print()

    # 4. Save outputs
    df.round(2).to_csv(OUTPUT_DIR / "bioclim_raw.csv")
    df_z.round(3).to_csv(OUTPUT_DIR / "bioclim_zscore.csv")
    ranking.round(3).to_csv(OUTPUT_DIR / "similarity_ranking.csv")

    print(f"Outputs saved to: {OUTPUT_DIR}/")
    return df, df_z, ranking


if __name__ == "__main__":
    main()
