// =============================================================================
// SENTINEL-2 VALIDATION OF i-TREE CANOPY ESTIMATES
// Lake Eymir, Ankara, Turkiye  -  POINT-LEVEL + POLYGON-LEVEL VERSION
// =============================================================================
// This version uses:
//   (a) The original i-Tree sampling polygon, reconstructed from 20,255 export-
//       ed sampling points using an alpha-shape concave hull (alpha = 1000),
//       which faithfully reproduces the lake-shore concavities.
//   (b) The 20,255 i-Tree sampling points themselves, queried point-by-point
//       against Sentinel-2 NDVI to provide direct point-level validation of
//       i-Tree's 71.48% Tree/Shrub estimate.
//
// Methods executed:
//   1. Polygon-level binary NDVI thresholds (sensitivity)
//   2. Polygon-level sub-pixel fractional cover (FCover, with endmember
//      sensitivity)
//   3. POINT-LEVEL validation: NDVI sampled at each of the 20,255 i-Tree
//      sampling locations
//   4. ESA WorldCover 2021 cross-check (polygon and point levels)
//   5. Dynamic World 2023-2025 cross-check (polygon and point levels)
//
// REQUIREMENT: Upload itree_points.csv as a GEE FeatureCollection asset and
// update POINTS_ASSET_PATH below.
//
// Author: Funda Yakar (fundayakar@gmail.com)
// =============================================================================

// -----------------------------------------------------------------------------
// CONFIGURATION  -  UPDATE WITH YOUR ASSET PATH
// -----------------------------------------------------------------------------
var POINTS_ASSET_PATH = 'projects/seismic-relic-481709-r8/assets/itree_points';

// -----------------------------------------------------------------------------
// 1. STUDY AREA POLYGON (reconstructed from i-Tree points, alpha=1000)
// -----------------------------------------------------------------------------
var eymirCoords = [
  [32.826378, 39.823177], [32.828326, 39.822859], [32.829042, 39.822143], [32.832785, 39.822864],
  [32.833262, 39.823033], [32.834370, 39.824470], [32.834671, 39.825828], [32.834183, 39.826914],
  [32.832124, 39.828413], [32.829985, 39.829186], [32.828805, 39.830038], [32.827394, 39.830278],
  [32.826526, 39.828816], [32.828463, 39.827384], [32.830403, 39.826605], [32.830879, 39.825814],
  [32.830673, 39.825277], [32.829607, 39.825116], [32.826107, 39.825982], [32.822897, 39.825685],
  [32.820809, 39.824741], [32.818786, 39.824426], [32.816213, 39.822888], [32.815705, 39.821807],
  [32.816246, 39.820098], [32.816018, 39.818015], [32.816530, 39.816983], [32.816426, 39.815807],
  [32.815695, 39.814531], [32.814799, 39.815206], [32.814552, 39.815974], [32.812541, 39.818504],
  [32.812528, 39.820274], [32.812965, 39.822135], [32.814277, 39.823459], [32.814197, 39.824939],
  [32.815658, 39.825232], [32.817910, 39.826443], [32.819610, 39.826084], [32.821010, 39.826196],
  [32.824199, 39.827705], [32.824850, 39.828662], [32.824813, 39.831588], [32.826705, 39.832298],
  [32.829498, 39.834195], [32.830557, 39.833809], [32.832163, 39.833876], [32.834454, 39.832606],
  [32.837242, 39.831886], [32.838928, 39.832914], [32.843804, 39.832137], [32.845380, 39.830589],
  [32.845917, 39.829352], [32.847425, 39.828512], [32.848193, 39.827651], [32.849098, 39.827387],
  [32.849671, 39.826690], [32.847472, 39.826369], [32.845064, 39.824995], [32.844106, 39.825222],
  [32.842788, 39.826567], [32.841537, 39.827060], [32.840454, 39.827173], [32.838608, 39.826662],
  [32.837448, 39.826706], [32.836622, 39.826179], [32.836551, 39.825386], [32.837105, 39.823812],
  [32.836806, 39.822758], [32.834969, 39.821213], [32.833260, 39.820472], [32.832515, 39.818675],
  [32.831917, 39.818656], [32.829625, 39.819783], [32.828407, 39.819629], [32.826520, 39.821261],
  [32.825342, 39.820865], [32.824843, 39.820598], [32.824022, 39.819183], [32.824864, 39.816527],
  [32.821952, 39.814377], [32.821565, 39.813768], [32.820791, 39.813627], [32.820885, 39.817223],
  [32.820304, 39.820777], [32.820691, 39.821784], [32.821237, 39.822508], [32.822216, 39.822906],
  [32.824335, 39.822758], [32.826378, 39.823177]
];

var studyArea = ee.FeatureCollection([
  ee.Feature(ee.Geometry.Polygon([eymirCoords]))
]);

Map.centerObject(studyArea, 14);
Map.addLayer(studyArea.style({color: 'red', fillColor: '00000000', width: 2}),
             {}, 'i-Tree study polygon (reconstructed)');

print('=== STUDY AREA ===');
print('Polygon area (km²):', studyArea.geometry().area().divide(1e6));
print('i-Tree reported area (km²): 1.90');

// -----------------------------------------------------------------------------
// 2. LOAD i-TREE SAMPLING POINTS
// -----------------------------------------------------------------------------
var itreePoints = ee.FeatureCollection(POINTS_ASSET_PATH);
print('=== i-TREE SAMPLING POINTS ===');
print('Total points loaded:', itreePoints.size());

Map.addLayer(itreePoints.style({color: 'yellow', pointSize: 1}),
             {}, 'i-Tree sampling points', false);

// -----------------------------------------------------------------------------
// 3. CLOUD MASK
// -----------------------------------------------------------------------------
function maskS2clouds(image) {
  var qa = image.select('QA60');
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
    .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000);
}

// -----------------------------------------------------------------------------
// 4. SPRING PEAK COMPOSITE (April–June, multi-year median 2023–2025)
// -----------------------------------------------------------------------------
var s2_spring = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
  .filterBounds(studyArea)
  .filter(ee.Filter.calendarRange(4, 6, 'month'))
  .filter(ee.Filter.calendarRange(2023, 2025, 'year'))
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
  .map(maskS2clouds);

print('Sentinel-2 spring images (Apr-Jun 2023-2025):', s2_spring.size());

var spring_composite = s2_spring.median().clip(studyArea);
var ndvi_spring = spring_composite.normalizedDifference(['B8', 'B4']).rename('NDVI');
var mndwi_spring = spring_composite.normalizedDifference(['B3', 'B11']).rename('MNDWI');

Map.addLayer(spring_composite,
  {bands: ['B4', 'B3', 'B2'], min: 0, max: 0.3},
  'Sentinel-2 spring RGB (2023-2025)');

Map.addLayer(ndvi_spring,
  {min: -0.2, max: 0.9,
   palette: ['blue', 'white', 'lightgreen', 'darkgreen']},
  'NDVI (spring)');

// -----------------------------------------------------------------------------
// 5. WATER MASK
// -----------------------------------------------------------------------------
var waterMask = mndwi_spring.gt(0);
var landMask = waterMask.not();

var pixelArea = ee.Image.pixelArea();

var vegZoneArea = landMask.multiply(pixelArea).reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: studyArea.geometry(), scale: 10, maxPixels: 1e10
});
var vegZoneArea_km2 = ee.Number(vegZoneArea.get('MNDWI')).divide(1e6);
print('Vegetated zone area (km², after water masking):', vegZoneArea_km2);

// -----------------------------------------------------------------------------
// 6. METHOD 1: POLYGON-LEVEL BINARY NDVI THRESHOLDS
// -----------------------------------------------------------------------------
var thresholds = [0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50];

print('=== METHOD 1: POLYGON-LEVEL NDVI THRESHOLDS (spring, water masked) ===');

thresholds.forEach(function(thr) {
  var canopy = ndvi_spring.gt(thr).and(landMask);
  var canopyArea = canopy.multiply(pixelArea).reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: studyArea.geometry(), scale: 10, maxPixels: 1e10
  });
  var fraction_pct = ee.Number(canopyArea.get('NDVI'))
    .divide(ee.Number(vegZoneArea.get('MNDWI'))).multiply(100);
  print('NDVI > ' + thr + ' canopy fraction (%):', fraction_pct);
});

// -----------------------------------------------------------------------------
// 7. METHOD 2: POLYGON-LEVEL SUB-PIXEL FCOVER
// -----------------------------------------------------------------------------
var fcover_spring = ndvi_spring.subtract(0.15)
  .divide(0.85 - 0.15)
  .clamp(0, 1)
  .updateMask(landMask)
  .rename('FCover');

Map.addLayer(fcover_spring,
  {min: 0, max: 1,
   palette: ['white', 'lightgreen', 'green', 'darkgreen']},
  'FCover (sub-pixel canopy fraction)');

var canopyArea_fcover = fcover_spring.multiply(pixelArea).reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: studyArea.geometry(), scale: 10, maxPixels: 1e10
});
var fcover_fraction = ee.Number(canopyArea_fcover.get('FCover'))
  .divide(ee.Number(vegZoneArea.get('MNDWI'))).multiply(100);

print('=== METHOD 2: POLYGON-LEVEL FCover (NDVI_soil=0.15, NDVI_veg=0.85) ===');
print('Aggregated canopy fraction (%):', fcover_fraction);

var endmemberPairs = [
  {soil: 0.10, veg: 0.85},
  {soil: 0.15, veg: 0.80},
  {soil: 0.15, veg: 0.85},
  {soil: 0.15, veg: 0.90},
  {soil: 0.20, veg: 0.85}
];

print('=== METHOD 2 SENSITIVITY: alternative endmembers ===');
endmemberPairs.forEach(function(em) {
  var fc = ndvi_spring.subtract(em.soil)
    .divide(em.veg - em.soil)
    .clamp(0, 1)
    .updateMask(landMask)
    .rename('FCover');
  var ca = fc.multiply(pixelArea).reduceRegion({
    reducer: ee.Reducer.sum(),
    geometry: studyArea.geometry(), scale: 10, maxPixels: 1e10
  });
  var frac = ee.Number(ca.get('FCover'))
    .divide(ee.Number(vegZoneArea.get('MNDWI'))).multiply(100);
  print('FCover (soil=' + em.soil + ', veg=' + em.veg + ') (%):', frac);
});

// -----------------------------------------------------------------------------
// 8. METHOD 3: POINT-LEVEL VALIDATION (KEY METHOD)
//    Sample NDVI at each of the 20,255 original i-Tree sampling locations.
// -----------------------------------------------------------------------------
var sampledPoints = ndvi_spring.sampleRegions({
  collection: itreePoints,
  scale: 10,
  geometries: false
});

print('=== METHOD 3: POINT-LEVEL NDVI AT i-TREE SAMPLING LOCATIONS ===');
print('Points successfully sampled:', sampledPoints.size());

thresholds.forEach(function(thr) {
  var aboveThr = sampledPoints.filter(ee.Filter.gt('NDVI', thr));
  var pctAbove = ee.Number(aboveThr.size())
    .divide(ee.Number(sampledPoints.size()))
    .multiply(100);
  print('Points with NDVI > ' + thr + ' (% of total):', pctAbove);
});

var ndviStats = sampledPoints.aggregate_stats('NDVI');
print('Point-level NDVI summary statistics:', ndviStats);

// FCover at points
var fcoverImg = ndvi_spring.subtract(0.15)
  .divide(0.85 - 0.15)
  .clamp(0, 1)
  .rename('FCover');
var sampledFcover = fcoverImg.sampleRegions({
  collection: itreePoints,
  scale: 10,
  geometries: false
});
var fcoverMean = sampledFcover.aggregate_mean('FCover');
print('Point-level mean FCover (%):', ee.Number(fcoverMean).multiply(100));

// -----------------------------------------------------------------------------
// 9. METHOD 4: ESA WORLDCOVER 2021
// -----------------------------------------------------------------------------
var worldcover = ee.ImageCollection('ESA/WorldCover/v200').first().clip(studyArea);
var wc_treeshrub = worldcover.eq(10).or(worldcover.eq(20)).and(landMask);

var wc_area = wc_treeshrub.multiply(pixelArea).reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: studyArea.geometry(), scale: 10, maxPixels: 1e10
});
var wc_fraction = ee.Number(wc_area.get('Map'))
  .divide(ee.Number(vegZoneArea.get('MNDWI'))).multiply(100);

print('=== METHOD 4: ESA WorldCover 2021 ===');
print('Polygon-level Tree+Shrub fraction (%):', wc_fraction);

var wc_at_points = worldcover.sampleRegions({
  collection: itreePoints,
  scale: 10,
  geometries: false
});
var wc_treeshrub_pts = wc_at_points
  .filter(ee.Filter.or(ee.Filter.eq('Map', 10), ee.Filter.eq('Map', 20)));
var wc_pct_pts = ee.Number(wc_treeshrub_pts.size())
  .divide(ee.Number(wc_at_points.size())).multiply(100);
print('Point-level Tree+Shrub at i-Tree locations (%):', wc_pct_pts);

// -----------------------------------------------------------------------------
// 10. METHOD 5: DYNAMIC WORLD 2023-2025
// -----------------------------------------------------------------------------
var dw = ee.ImageCollection('GOOGLE/DYNAMICWORLD/V1')
  .filterBounds(studyArea)
  .filter(ee.Filter.calendarRange(4, 9, 'month'))
  .filter(ee.Filter.calendarRange(2023, 2025, 'year'))
  .select('label')
  .mode()
  .clip(studyArea);
var dw_treeshrub = dw.eq(1).or(dw.eq(5)).and(landMask);

var dw_area = dw_treeshrub.multiply(pixelArea).reduceRegion({
  reducer: ee.Reducer.sum(),
  geometry: studyArea.geometry(), scale: 10, maxPixels: 1e10
});
var dw_fraction = ee.Number(dw_area.get('label'))
  .divide(ee.Number(vegZoneArea.get('MNDWI'))).multiply(100);

print('=== METHOD 5: Dynamic World 2023-2025 ===');
print('Polygon-level Tree+Shrub fraction (%):', dw_fraction);

var dw_at_points = dw.sampleRegions({
  collection: itreePoints,
  scale: 10,
  geometries: false
});
var dw_treeshrub_pts = dw_at_points
  .filter(ee.Filter.or(ee.Filter.eq('label', 1), ee.Filter.eq('label', 5)));
var dw_pct_pts = ee.Number(dw_treeshrub_pts.size())
  .divide(ee.Number(dw_at_points.size())).multiply(100);
print('Point-level Tree+Shrub at i-Tree locations (%):', dw_pct_pts);

// -----------------------------------------------------------------------------
// 11. SUMMARY
// -----------------------------------------------------------------------------
print('===========================================================');
print('FINAL COMPARISON');
print('===========================================================');
print('i-Tree Canopy Tree/Shrub estimate:                 71.48%');
print('-----------------------------------------------------------');
print('Method 3 (point-level NDVI) is the strongest validation:');
print('it queries Sentinel-2 at the exact 20,255 locations');
print('originally classified by i-Tree.');
