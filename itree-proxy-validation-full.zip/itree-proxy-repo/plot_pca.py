"""
plot_pca.py
===========

PCA visualization of bioclimatic similarity space. Projects all candidate
proxy cities onto the first two principal components and highlights Ankara.

Run climate_similarity.py first to generate outputs/bioclim_zscore.csv.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

OUTPUT_DIR = Path(__file__).parent / "outputs"
FIG_DIR = Path(__file__).parent / "figures"
FIG_DIR.mkdir(exist_ok=True)


def pca_2d(X):
    """Simple PCA returning 2-D scores and explained variance ratios."""
    X_centered = X - X.mean(axis=0)
    U, S, Vt = np.linalg.svd(X_centered, full_matrices=False)
    scores = U[:, :2] * S[:2]
    var = (S ** 2) / (X.shape[0] - 1)
    explained = var / var.sum()
    return scores, explained[:2], Vt[:2]


def main():
    df_z = pd.read_csv(OUTPUT_DIR / "bioclim_zscore.csv", index_col=0)
    X = df_z.values
    scores, explained, components = pca_2d(X)

    fig, ax = plt.subplots(figsize=(8, 6.5))

    # Plot all cities
    for i, city in enumerate(df_z.index):
        x, y = scores[i, 0], scores[i, 1]
        if city == "Ankara":
            ax.scatter(x, y, s=260, c="#c0392b", marker="*",
                       edgecolor="black", linewidth=1.2, zorder=5)
            ax.annotate("Ankara", (x, y), xytext=(8, 8),
                        textcoords="offset points", fontsize=11,
                        fontweight="bold", color="#c0392b")
        elif city == "Denver_USA":
            ax.scatter(x, y, s=160, c="#2980b9", marker="o",
                       edgecolor="black", linewidth=1.0, zorder=4)
            ax.annotate(city.replace("_", " "), (x, y),
                        xytext=(8, -4), textcoords="offset points",
                        fontsize=10, color="#2980b9", fontweight="bold")
        else:
            ax.scatter(x, y, s=90, c="lightgray", marker="o",
                       edgecolor="black", linewidth=0.6, zorder=3)
            ax.annotate(city.replace("_", " "), (x, y),
                        xytext=(7, -4), textcoords="offset points",
                        fontsize=9, color="dimgray")

    # Connecting line Ankara - Denver
    ankara_idx = list(df_z.index).index("Ankara")
    denver_idx = list(df_z.index).index("Denver_USA")
    ax.plot([scores[ankara_idx, 0], scores[denver_idx, 0]],
            [scores[ankara_idx, 1], scores[denver_idx, 1]],
            "--", color="#2980b9", alpha=0.5, linewidth=1.2, zorder=2)

    ax.axhline(0, color="gray", linewidth=0.5, alpha=0.5)
    ax.axvline(0, color="gray", linewidth=0.5, alpha=0.5)
    ax.set_xlabel(f"PC1 ({explained[0]*100:.1f}% variance)", fontsize=11)
    ax.set_ylabel(f"PC2 ({explained[1]*100:.1f}% variance)", fontsize=11)
    ax.set_title("Bioclimatic similarity space: Ankara vs candidate proxy cities\n"
                 "(PCA on standardized MAT, MAP, TSEAS, PSEAS, AI)",
                 fontsize=11)
    ax.grid(alpha=0.25)

    plt.tight_layout()
    out_png = FIG_DIR / "fig2_pca_climate_similarity.png"
    out_pdf = FIG_DIR / "fig2_pca_climate_similarity.pdf"
    plt.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.savefig(out_pdf, bbox_inches="tight")
    plt.close()

    print(f"Saved: {out_png}")
    print(f"Saved: {out_pdf}")
    print(f"Explained variance: PC1 = {explained[0]*100:.1f}%, "
          f"PC2 = {explained[1]*100:.1f}% "
          f"(cumulative {(explained[0]+explained[1])*100:.1f}%)")


if __name__ == "__main__":
    main()
