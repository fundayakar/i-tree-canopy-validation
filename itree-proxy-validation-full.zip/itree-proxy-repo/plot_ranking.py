"""
plot_ranking.py
===============

Bar chart of Euclidean distance from Ankara for all candidate proxy cities.

Run climate_similarity.py first to generate outputs/similarity_ranking.csv.
"""

import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

OUTPUT_DIR = Path(__file__).parent / "outputs"
FIG_DIR = Path(__file__).parent / "figures"
FIG_DIR.mkdir(exist_ok=True)


def main():
    df = pd.read_csv(OUTPUT_DIR / "similarity_ranking.csv", index_col=0)
    df = df.sort_values("Euclidean_distance")

    colors = []
    for city in df.index:
        if city == "Denver_USA":
            colors.append("#2980b9")
        elif "USA" in city:
            colors.append("#7fb3d5")
        else:
            colors.append("lightgray")

    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    labels = [c.replace("_", " ") for c in df.index]
    bars = ax.barh(labels, df["Euclidean_distance"],
                   color=colors, edgecolor="black", linewidth=0.7)

    for bar, val in zip(bars, df["Euclidean_distance"]):
        ax.text(val + 0.06, bar.get_y() + bar.get_height() / 2,
                f"{val:.2f}", va="center", fontsize=9.5)

    ax.invert_yaxis()
    ax.set_xlabel("Euclidean distance from Ankara (standardized 5-D space)",
                  fontsize=11)
    ax.set_title("Climate similarity ranking of candidate proxy cities\n"
                 "(lower = more similar to Ankara)", fontsize=11)
    ax.grid(axis="x", alpha=0.3)
    ax.set_xlim(0, df["Euclidean_distance"].max() * 1.18)

    # Annotation box
    ax.annotate("Selected\nproxy",
                xy=(df["Euclidean_distance"].iloc[0], 0),
                xytext=(1.4, 0.6),
                fontsize=10, color="#2980b9", fontweight="bold",
                arrowprops=dict(arrowstyle="->", color="#2980b9", lw=1.2))

    plt.tight_layout()
    out_png = FIG_DIR / "fig3_similarity_ranking.png"
    out_pdf = FIG_DIR / "fig3_similarity_ranking.pdf"
    plt.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.savefig(out_pdf, bbox_inches="tight")
    plt.close()

    print(f"Saved: {out_png}")
    print(f"Saved: {out_pdf}")


if __name__ == "__main__":
    main()
