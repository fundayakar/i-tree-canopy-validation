"""
Fix the polygon: detect interior 'holes' (lake) and create a polygon with
hole, OR alternatively use Sentinel-2 NDVI to derive land mask and intersect
with the alpha shape.

Approach: rasterize the polygon, mask out water pixels (NDVI < 0.05), then
revectorize. This gives a polygon that excludes the lake area entirely.
"""
import numpy as np
import rasterio
from rasterio import features
from shapely.geometry import shape, mapping
from shapely.ops import unary_union
import json
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from rasterio.plot import reshape_as_image

# Load polygon
with open("/home/claude/eymir_polygon/itree_polygon_simplified.json") as f:
    poly_coords = json.load(f)

# Load NDVI raster (use as the spatial reference)
with rasterio.open("/mnt/user-data/uploads/Eymir_NDVI_spring.tif") as src:
    ndvi = src.read(1)
    transform = src.transform
    out_shape = src.shape
    crs = src.crs
    bounds = src.bounds

# Rasterize the polygon (1 inside, 0 outside)
poly_geom = {"type": "Polygon", "coordinates": [poly_coords]}
poly_raster = features.rasterize(
    [(poly_geom, 1)],
    out_shape=out_shape,
    transform=transform,
    fill=0,
    dtype="uint8"
)

# Land mask: inside polygon AND NDVI >= 0.05
land_mask = (poly_raster == 1) & (ndvi >= 0.05) & ~np.isnan(ndvi)
print(f"Land pixels: {land_mask.sum()}")
print(f"Polygon pixels: {(poly_raster == 1).sum()}")
print(f"Water pixels in polygon: {((poly_raster == 1) & (ndvi < 0.05)).sum()}")

# Revectorize the land mask to get clean polygon (with hole for the lake)
shapes_gen = features.shapes(
    land_mask.astype("uint8"), mask=land_mask, transform=transform)
geoms = []
for geom, val in shapes_gen:
    if val == 1:
        geoms.append(shape(geom))

if geoms:
    final_geom = unary_union(geoms)
    print(f"Geom type: {final_geom.geom_type}")
    if final_geom.geom_type == 'MultiPolygon':
        # Keep only the largest piece
        largest = max(final_geom.geoms, key=lambda g: g.area)
        final_geom = largest
    
    # Simplify a bit
    final_geom = final_geom.simplify(0.0001, preserve_topology=True)
    print(f"Final geom type after simplify: {final_geom.geom_type}")
    
    # Check holes
    if final_geom.geom_type == 'Polygon':
        n_holes = len(final_geom.interiors)
        print(f"Number of interior holes (lake bodies): {n_holes}")
        
        # Save
        gj = mapping(final_geom)
        with open("/home/claude/eymir_polygon/itree_polygon_with_lake_hole.geojson", "w") as f:
            json.dump({
                "type": "FeatureCollection",
                "features": [{"type": "Feature", "properties": {}, "geometry": gj}]
            }, f, indent=2)
        print("Saved polygon with lake hole as GeoJSON")
        
        # Save the exterior + holes for plotting
        ext_coords = list(final_geom.exterior.coords)
        hole_coords_list = [list(h.coords) for h in final_geom.interiors]
        
        with open("/home/claude/eymir_polygon/poly_with_holes.json", "w") as f:
            json.dump({
                "exterior": ext_coords,
                "holes": hole_coords_list
            }, f)
