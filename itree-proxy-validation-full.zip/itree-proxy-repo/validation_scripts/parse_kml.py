"""
Parse i-Tree KML export to extract sampling points.
"""
import re
from pathlib import Path
import json

kml_path = Path("/mnt/user-data/uploads/i-tree-project-export.kml")
text = kml_path.read_text()

# Extract all coordinate pairs (lon, lat)
pattern = r'<coordinates>([\d\.\-]+),([\d\.\-]+)</coordinates>'
matches = re.findall(pattern, text)

points = [(float(lon), float(lat)) for lon, lat in matches]
print(f"Total points extracted: {len(points)}")
print(f"First 3: {points[:3]}")
print(f"Last 3:  {points[-3:]}")

# Bounds
lons = [p[0] for p in points]
lats = [p[1] for p in points]
print(f"\nBounds:")
print(f"  Lon: {min(lons):.6f} to {max(lons):.6f}")
print(f"  Lat: {min(lats):.6f} to {max(lats):.6f}")

# Save as JSON for later use
out_dir = Path("/home/claude/eymir_polygon")
out_dir.mkdir(exist_ok=True)
with open(out_dir / "itree_points.json", "w") as f:
    json.dump(points, f)
print(f"\nSaved to: {out_dir / 'itree_points.json'}")
