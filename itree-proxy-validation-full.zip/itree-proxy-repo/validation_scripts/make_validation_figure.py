"""
Final panel figure with the corrected polygon that excludes lake interiors.
"""
import numpy as np
import rasterio
from rasterio.plot import reshape_as_image
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import json
from pathlib import Path

# Polygon with holes
with open("/home/claude/eymir_polygon/poly_with_holes.json") as f:
    poly_data = json.load(f)
exterior = np.array(poly_data["exterior"])
holes = [np.array(h) for h in poly_data["holes"]]

# Rasters
def load_raster(path, band=1):
    with rasterio.open(path) as src:
        arr = src.read(band) if isinstance(band, int) else src.read()
        bounds = src.bounds
    return arr, bounds

rgb_arr, bounds = load_raster("/mnt/user-data/uploads/Eymir_S2_RGB_spring.tif", band=None)
ndvi_arr, _ = load_raster("/mnt/user-data/uploads/Eymir_NDVI_spring.tif", band=1)
fcover_arr, _ = load_raster("/mnt/user-data/uploads/Eymir_FCover_spring.tif", band=1)

# Build OUTER polygon raster mask using the original alpha shape (lake INCLUDED)
# This defines the full study extent inside which we identify water
with open("/home/claude/eymir_polygon/itree_polygon_simplified.json") as f:
    outer_poly_coords = json.load(f)

import rasterio.features as rfeatures
outer_geom = {"type": "Polygon", "coordinates": [outer_poly_coords]}

with rasterio.open("/mnt/user-data/uploads/Eymir_NDVI_spring.tif") as src:
    poly_mask_inside = rfeatures.rasterize(
        [(outer_geom, 1)], out_shape=src.shape, transform=src.transform,
        fill=0, dtype="uint8"
    ).astype(bool)

# Water mask: inside the outer polygon AND (NaN in NDVI OR very low NDVI)
water_mask = poly_mask_inside & (np.isnan(ndvi_arr) | (ndvi_arr < 0.1))
print(f"Water pixels detected: {water_mask.sum()}")

# Brighten RGB
rgb_img = reshape_as_image(rgb_arr)
rgb_img = np.clip(rgb_img, 0, 1)
rgb_img = np.power(rgb_img, 0.55)
rgb_img = np.clip(rgb_img, 0, 1)

ndvi_disp = np.where(water_mask | np.isnan(ndvi_arr), np.nan, ndvi_arr)
fcover_disp = np.where(water_mask | (fcover_arr <= 0.001), np.nan, fcover_arr)

extent = [bounds.left, bounds.right, bounds.bottom, bounds.top]

fig, axes = plt.subplots(1, 3, figsize=(16, 6.2))

ndvi_cmap = LinearSegmentedColormap.from_list(
    "ndvi", ["#7c4f1e", "#f0e6c8", "#a6d96a", "#1a6b2e"], N=256)
fcover_cmap = LinearSegmentedColormap.from_list(
    "fcover", ["#fffaf0", "#c8e6b8", "#5fa650", "#1a4d18"], N=256)

def add_water_overlay(ax, water_mask, extent):
    """Add water as a flat white overlay on top of analysis maps."""
    water_rgba = np.zeros((*water_mask.shape, 4))
    water_rgba[water_mask, 0] = 1.0
    water_rgba[water_mask, 1] = 1.0
    water_rgba[water_mask, 2] = 1.0
    water_rgba[water_mask, 3] = 1.0
    ax.imshow(water_rgba, extent=extent, origin='upper', interpolation='nearest')

def plot_polygon(ax, exterior, holes, color='red', lw=1.5, alpha=0.9):
    """Plot exterior + holes as outline only."""
    ax.plot(exterior[:, 0], exterior[:, 1], color=color, linewidth=lw, alpha=alpha)
    # Filter out tiny holes (< 5 vertices likely noise)
    for h in holes:
        if len(h) >= 6:
            ax.plot(h[:, 0], h[:, 1], color=color, linewidth=lw, alpha=alpha)

# (a) RGB - replace water pixels with flat white directly
rgb_with_water = rgb_img.copy()
rgb_with_water[water_mask] = [1.0, 1.0, 1.0]  # white for water

ax = axes[0]
ax.imshow(rgb_with_water, extent=extent, origin='upper')
plot_polygon(ax, exterior, holes)
ax.set_title("(a) Sentinel-2 RGB composite\nSpring 2023-2025 median", fontsize=11)
ax.set_xlabel("Longitude (°E)", fontsize=10)
ax.set_ylabel("Latitude (°N)", fontsize=10)
ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])
ax.tick_params(labelsize=8)

# (b) FCover
ax = axes[1]
im = ax.imshow(fcover_disp, extent=extent, origin='upper',
               cmap=fcover_cmap, vmin=0, vmax=1)
add_water_overlay(ax, water_mask, extent)
plot_polygon(ax, exterior, holes)
ax.set_title("(b) Sub-pixel canopy fraction (FCover)\nNDVI rescaled, water masked",
             fontsize=11)
ax.set_xlabel("Longitude (°E)", fontsize=10)
ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])
ax.tick_params(labelsize=8)
ax.set_yticklabels([])
cbar = plt.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
cbar.set_label("FCover (-)", fontsize=9)
cbar.ax.tick_params(labelsize=8)

# (c) NDVI
ax = axes[2]
im = ax.imshow(ndvi_disp, extent=extent, origin='upper',
               cmap=ndvi_cmap, vmin=-0.1, vmax=0.85)
add_water_overlay(ax, water_mask, extent)
plot_polygon(ax, exterior, holes)
ax.set_title("(c) NDVI map\nSpring 2023-2025 median, water masked",
             fontsize=11)
ax.set_xlabel("Longitude (°E)", fontsize=10)
ax.set_xlim(extent[0], extent[1])
ax.set_ylim(extent[2], extent[3])
ax.tick_params(labelsize=8)
ax.set_yticklabels([])
cbar = plt.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
cbar.set_label("NDVI (-)", fontsize=9)
cbar.ax.tick_params(labelsize=8)

plt.tight_layout()

out_dir = Path("/home/claude/itree-proxy-repo/figures")
plt.savefig(out_dir / "fig4_sentinel2_validation.png", dpi=300, bbox_inches='tight')
plt.savefig(out_dir / "fig4_sentinel2_validation.pdf", bbox_inches='tight')
plt.close()

print("Saved fig4_sentinel2_validation.png and .pdf")
