"""
Derive the i-Tree study area polygon from sampling points using alpha shape.

The alpha shape captures the concave outline (including lake indentations)
better than a convex hull, providing a faithful reconstruction of the original
i-Tree polygon boundary.
"""
import json
import numpy as np
import alphashape
from shapely.geometry import Polygon, Point, mapping
from pathlib import Path
import matplotlib.pyplot as plt

points_path = Path("/home/claude/eymir_polygon/itree_points.json")
points = json.load(open(points_path))
pts_array = np.array(points)
print(f"Loaded {len(points)} points")

# Test multiple alpha values to find one that captures concavity
# (lake) without holes; higher alpha = tighter, can split into pieces
alphas = [0, 50, 100, 200, 300, 500, 1000]

results = []
for a in alphas:
    try:
        shape = alphashape.alphashape(points, a)
        if shape.geom_type == 'Polygon':
            area_deg2 = shape.area
            # Approx area in km² at lat=39.82
            # 1 deg lat = 111 km, 1 deg lon = 111 * cos(39.82) = 85.3 km
            area_km2 = area_deg2 * 111 * 85.3
            results.append((a, 'Polygon', area_km2, shape))
            print(f"alpha={a}: Polygon, area = {area_km2:.3f} km²")
        elif shape.geom_type == 'MultiPolygon':
            # multiple pieces
            num = len(shape.geoms)
            total_area = sum(g.area for g in shape.geoms) * 111 * 85.3
            results.append((a, 'MultiPolygon', total_area, shape))
            print(f"alpha={a}: MultiPolygon ({num} pieces), area = {total_area:.3f} km²")
    except Exception as e:
        print(f"alpha={a}: ERROR - {e}")

# Select alpha=100 or 200 typically; pick the one that gives best balance
# Plot all candidates
fig, axes = plt.subplots(2, 4, figsize=(20, 10))
axes = axes.flatten()

for i, (a, gtype, area, shape) in enumerate(results):
    if i >= len(axes):
        break
    ax = axes[i]
    ax.scatter(pts_array[:, 0], pts_array[:, 1], s=0.5, c='gray', alpha=0.4)
    
    if shape.geom_type == 'Polygon':
        x, y = shape.exterior.xy
        ax.plot(x, y, 'r-', linewidth=2)
    else:
        for geom in shape.geoms:
            x, y = geom.exterior.xy
            ax.plot(x, y, 'r-', linewidth=2)
    
    ax.set_title(f'alpha={a}\n{gtype}, area={area:.2f} km²')
    ax.set_aspect('equal')

# Hide unused
for j in range(len(results), len(axes)):
    axes[j].set_visible(False)

plt.tight_layout()
plt.savefig('/home/claude/eymir_polygon/alpha_comparison.png', dpi=120, bbox_inches='tight')
print("\nComparison figure saved")
plt.close()
